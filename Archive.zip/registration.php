<?php

    $con=new MySQLi("localhost","root","","votingdb");
    
    //$sid = $_REQUEST["sid"];
     $fname = $_POST["fname"];
     $lname = $_POST["lname"];
     $email = $_POST["email"];
     $password = $_POST["password"];
    $user_type = $_POST["type"];

      $qu="insert into tbluserreg (user_fname,user_lname,user_email,user_password,user_type) values ('$fname','$lname','$email','$password','$user_type')";

    $con->query($qu);
    echo"success";
    
?>

