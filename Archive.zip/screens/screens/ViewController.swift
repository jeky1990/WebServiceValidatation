//
//  ViewController.swift
//  screens
//
//  Created by TOPS on 9/8/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UINavigationBarDelegate {

    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var txt2: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        txt1.placeholder = "user name";
        txt2.placeholder = "password" ;
    }

    
    @IBAction func login(_ sender: Any) {
        
        
        
        let url = URL(string: "http://localhost/votingapp/select.php/");
        let strbody = "email=\(txt1.text!)&password=\(txt2.text!)";
        var request = URLRequest(url: url!);
        
        request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length");
        request.httpBody = strbody.data(using: String.Encoding.utf8);
        request.httpMethod = "POST";
        
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            
            let resp = String(data: data1!, encoding: String.Encoding.utf8);
            print(resp!);
            
            
            DispatchQueue.main.async {
                
                 do
                 {
                    
                    
                    let arr = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                    
                    
                    if arr.count == 1
                    {
                        
                        
                        let alt = UIAlertController(title: "Conforamtion", message: "Login Successfully", preferredStyle: .alert)
                        
                        let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                            
                            
                            let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab");
                            self.navigationController?.pushViewController(stb!, animated: true);
                            
                            
                            
                            
                            
                        })
                        
                        alt.addAction(ok1);
                        self.present(alt, animated: true, completion:nil)
                        
                        
                        
                    }
                    else
                    {
                        
                        
                        let alt = UIAlertController(title: "Conforamtion", message: "Not login please try again ????", preferredStyle: .alert)
                        let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
                        alt.addAction(ok);
                        self.present(alt, animated: true, completion:nil)
                        
                        
                        
                        
                        
                    }

                    
                }catch
                {
                    
                    
                    
                }
                
                
                
            }
            
            
            
            
        }
        
        datatask.resume();
        

        
        
        
        
        
    }
    
    @IBAction func signup(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "signup")as! signup;
        self.navigationController? .pushViewController(stb, animated: true)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

