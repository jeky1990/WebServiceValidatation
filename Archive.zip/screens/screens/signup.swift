//
//  signup.swift
//  screens
//
//  Created by TOPS on 9/8/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class signup: UIViewController,UITableViewDataSource,UITableViewDelegate{

    var type  = "";
    @IBOutlet weak var txtpassword: UITextField!
    @IBOutlet weak var instruction: UILabel!
    @IBOutlet weak var fname: UITextField!
    @IBOutlet weak var lname: UITextField!
    @IBOutlet weak var email: UITextField!
    var arr : [String] = ["User","Participient"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fname.placeholder = "enter your first name";
        lname.placeholder = "enter your last name";
        email.placeholder = "enter your email.";
        txtpassword.placeholder = "enter your password";
        instruction.isHidden = true
    }
    
    @IBAction func edtpasbeg(_ sender: Any) {
        
        instruction.isHidden = false
        instruction.text = "password must be 8-10 characters and contain 1 capital letter,1 digit and atleast 1 special character";
    }
    
    @IBAction func edtpasend(_ sender: Any) {
        instruction.isHidden = true
    }
    @IBAction func password(_ sender: Any) {
        
        if IsValidPass(txtpassword: txtpassword.text!) {
            
            txtpassword.rightViewMode = .never
            txtpassword.clipsToBounds = true
            txtpassword.layer.borderWidth = 1
            txtpassword.layer.borderColor = UIColor.green.cgColor
            instruction.isHidden = true
        }
        else {
            
            txtpassword.layer.borderWidth = 1
            txtpassword.layer.borderColor = UIColor.red.cgColor
        }
    }
    @IBAction func emailvalidation(_ sender: UITextField) {
        instruction.isHidden = false
        if isValidEmail(email: email.text!) {
            
            email.rightViewMode = .never
            email.clipsToBounds = true
            email.layer.borderWidth = 1
            email.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            email.layer.borderWidth = 1
            email.layer.borderColor = UIColor.red.cgColor
        }
        instruction.text = "Enter in this format : Firstpart@secondPart.domainname"    }
    
    @IBAction func ending(_ sender: Any) {
        
        instruction.isHidden = true
    }
    @IBAction func submit(_ sender: Any) {
instruction.isHidden = true
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        return cell;
    }
   func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    type = arr[indexPath.row];
    
    print(arr[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        print([indexPath.row])
    }
    
    
    @IBAction func btnreg(_ sender: Any) {
        
        
        let url = URL(string: "http://localhost/votingapp/registration.php/");
        
        let strbody = "fname=\(fname.text!)&lname=\(lname.text!)&email=\(email.text!)&password=\(txtpassword.text!)&type=\(type)";
        
        var request = URLRequest(url: url!);
        
        request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length");
        request.httpBody = strbody.data(using: String.Encoding.utf8);
        request.httpMethod = "POST";
        
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
        
            let resp = String(data: data1!, encoding: String.Encoding.utf8);
            print(resp!);
            
            
            DispatchQueue.main.async {
                
                if resp! == "success\n"
                {
                    let alt = UIAlertController(title: "Conforamtion", message: "Registration Successfully ..", preferredStyle: .alert)
                    
                     let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                        
                        
                   let st = self.navigationController?.popViewController(animated: true);
                        
                        print(st);
                })
                 
                    alt.addAction(ok1);
                    self.present(alt, animated: true, completion:nil)

                    
                    
                }
                else
                {
                    
                    
                    let alt = UIAlertController(title: "Conforamtion", message: "not Register yet...???", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
                    alt.addAction(ok);
                    self.present(alt, animated: true, completion:nil)
                    
                    

                    
                    
                }
                
                
            }
            
            
            
            
        }
        
        datatask.resume();
        
        
    
        
        
        
    }
    func isValidEmail(email:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}";
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx);
        let result = emailTest.evaluate(with: email);
        return result;
    }

    func IsValidPass(txtpassword:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z]{8,10}";
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx);
        let result = emailTest.evaluate(with: txtpassword);
        return result;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
