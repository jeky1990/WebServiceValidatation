<?php
	
    $con=new mysqli("localhost","root","","votingdb");
    
    
    $email = $_POST["email"];
    $pass = $_POST ["password"];
    
     $qu = mysqli_query($con,"select * from tbluserreg where user_email = '$email' and user_password = '$pass'");
    if(mysqli_num_rows($qu) == 0){
        $row = array();
        
        print_r(json_encode($row));
    }
    else
    {
        
        
       // $rows = mysqli_num_rows($qu);
        while($row = mysqli_fetch_assoc($qu))
        {
            $pp[]  = $row;
            
        }
        //print_r($pp);
        echo json_encode($pp);

        
    }
    

    
?>

